<?php
require '../vendor/autoload.php';

use App\Calculadora;


$calc = new Calculadora(2,2,"dividir");

echo $calc->getResultado();

echo "<br> 5 + 5 = ".Calculadora::calcular(5,5,"soma");


 ?>
